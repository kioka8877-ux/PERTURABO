# Pack texte LOGO — A04

**Titre viral (6 mots max)** :
Restraining order vs her AND dad

**Paragraphe viral (4 lignes max)** :
A judge granted Tom Sandoval a temporary domestic violence restraining order against Victoria AND her father Will Robinson in June. Victoria's own attempt to get one against Tom was denied pending a future hearing.

**Metadata** :
- Title : Tom Sandoval's restraining order covers his ex AND her father — here's why
- Description :
At the end of June, Tom Sandoval was granted a temporary domestic violence restraining order against Victoria Lee Robinson and her father Will Robinson. Victoria's own protective order request against Tom was denied until a future hearing.

Videos and images used in this creation serve purely as illustration (fair use). They are not claimed or monetized beyond the permitted clip format.
- Tags : Tom Sandoval, restraining order, court case, celebrity news, Vanderpump Rules, drama

**On-screen** : HER AND HER DAD — BOTH NAMED
