# Pack texte LOGO — A01

**Titre viral (6 mots max)** :
Kicked in front of his band

**Paragraphe viral (4 lignes max)** :
Tom Sandoval says his ex Victoria kicked him in the groin in front of his band, crew and fans during a Florida tour stop. The insult that came with it, he says, hurt worse than the kick. New court filing is out.

**Metadata** :
- Title : Tom Sandoval says ex kicked him in front of his band — the insult that broke him
- Description :
Tom Sandoval claims his ex-girlfriend Victoria Lee Robinson kicked him in the groin in front of his band, tour crew and fans during an October tour stop in Florida, according to a new declaration in his restraining order case.

Videos and images used in this creation serve purely as illustration (fair use). They are not claimed or monetized beyond the permitted clip format.
- Tags : Tom Sandoval, Victoria Lee Robinson, Vanderpump Rules, celebrity drama, restraining order, TMZ

**On-screen** : SHE KICKED HIM IN FRONT OF HIS BAND
