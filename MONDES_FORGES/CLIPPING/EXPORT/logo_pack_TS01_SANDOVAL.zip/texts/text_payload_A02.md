# Pack texte LOGO — A02

**Titre viral (6 mots max)** :
4 words that broke him

**Paragraphe viral (4 lignes max)** :
Tom Sandoval says Victoria screamed insults at him in front of witnesses — the kind that left him 'frazzled' and 'anxious' before his America's Got Talent performance. He claims she questioned his manhood in the most humiliating way possible.

**Metadata** :
- Title : The 4 words she screamed that left Tom Sandoval 'frazzled' before AGT
- Description :
Tom Sandoval claims his ex Victoria Lee Robinson hurled insults at him — including degrading comments about his manhood — leaving him 'frazzled' and 'anxious' before his America's Got Talent quarterfinal performance in August 2025.

Videos and images used in this creation serve purely as illustration (fair use). They are not claimed or monetized beyond the permitted clip format.
- Tags : Tom Sandoval, AGT, celebrity scandal, toxic relationship, Vanderpump Rules, viral

**On-screen** : THE WORDS THAT BROKE HIM
