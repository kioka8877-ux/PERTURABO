# Pack texte LOGO — A03

**Titre viral (6 mots max)** :
She threatened the Ariana Madix treatment

**Paragraphe viral (4 lignes max)** :
Tom Sandoval says Victoria repeatedly warned she would 'destroy' his life and 'get the Ariana Madix treatment' — the public attention that followed his ex's breakup with him. He claims that's exactly why he stayed.

**Metadata** :
- Title : Why Tom Sandoval says he stayed: she threatened the 'Ariana Madix treatment'
- Description :
Tom Sandoval claims his ex Victoria Lee Robinson threatened to ruin his life and 'get the Ariana Madix treatment' — referencing the fame his former girlfriend gained after their split. He says the threat is why he stayed in the relationship.

Videos and images used in this creation serve purely as illustration (fair use). They are not claimed or monetized beyond the permitted clip format.
- Tags : Tom Sandoval, Ariana Madix, celebrity drama, breakup, Vanderpump Rules, TMZ

**On-screen** : 'I'LL GET THE ARIANA TREATMENT'
