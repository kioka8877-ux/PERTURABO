# Pack texte LOGO — A05

**Titre viral (6 mots max)** :
Her one sentence response changes everything

**Paragraphe viral (4 lignes max)** :
Victoria Lee Robinson says: 'I did not kick Tom, and I did not touch him.' She claims she took a shot, asked him to take care of her, and went back to bed. Two versions of the same night — only the court can decide.

**Metadata** :
- Title : Victoria Lee Robinson breaks her silence: 'I did not kick Tom'
- Description :
Victoria Lee Robinson denies the allegations: 'I did not kick Tom, and I did not touch him.' She says she had taken a shot, asked Tom to take care of her, and went back to bed on the bus — and that she keeps getting pulled back into the drama.

Videos and images used in this creation serve purely as illustration (fair use). They are not claimed or monetized beyond the permitted clip format.
- Tags : Victoria Lee Robinson, Tom Sandoval, he said she said, celebrity drama, Vanderpump Rules, viral

**On-screen** : HER SIDE OF THE STORY
