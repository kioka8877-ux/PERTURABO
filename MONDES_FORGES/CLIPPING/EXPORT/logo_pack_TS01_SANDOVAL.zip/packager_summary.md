# F05_PACKAGER — Synthèse des packs LOGO

- Pack : LOGO-TS01_SANDOVAL-SIEGE-LOGO-20260804T174153
- Sous-mode : informatif
- Videos : 5
- Schéma : /home/daytona/codebase/MONDES_FORGES/CLIPPING/PROFILES/logo/CONTRACTS/production_pack_schema_logo.json

| # | Angle | Titre | Cut | Logo |
|---|---|---|---|---|
| 1 | A01 | Kicked in front of his band | 12-47s (perturabo_validated) | image transparente campagne |
| 2 | A02 | 4 words that broke him | 60-95s (perturabo_validated) | image transparente campagne |
| 3 | A03 | She threatened the Ariana Madix treatmen | 130-165s (perturabo_validated) | image transparente campagne |
| 4 | A04 | Restraining order vs her AND dad | 200-235s (perturabo_validated) | image transparente campagne |
| 5 | A05 | Her one sentence response changes everyt | 260-295s (perturabo_validated) | image transparente campagne |

**5 videos prêtes → OMNIS_WATCH**
